package agenda;

public class NoExisteExcepcion extends Exception {

	public NoExisteExcepcion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoExisteExcepcion(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoExisteExcepcion(String message, Throwable cause) {
		super(message, cause);
	}

	public NoExisteExcepcion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoExisteExcepcion(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	


}
