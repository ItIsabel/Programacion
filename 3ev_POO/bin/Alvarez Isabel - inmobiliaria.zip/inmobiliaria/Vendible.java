package inmobiliaria;

public interface Vendible {
	public abstract void vender();

}
