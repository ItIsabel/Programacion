package inmobiliaria;

public interface Alquilable {
	public abstract void Alquilar();

}
