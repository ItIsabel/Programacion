package inmobiliaria;

public enum tipoConstruccion {
	nueva,
	segundaMano,

}
