package inmobiliaria;

public enum tipoGaraje {
	publico,
	privado

}
