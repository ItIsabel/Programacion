package inmobiliaria;

public class Superficie extends Inmueble{

	public Superficie(String ubicacion, int m2, int pvp) {
		super(ubicacion, m2, pvp);
	}
	

}
