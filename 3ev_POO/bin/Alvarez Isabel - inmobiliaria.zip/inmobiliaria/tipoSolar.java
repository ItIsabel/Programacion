package inmobiliaria;

public enum tipoSolar {
	urbano,
	rustico,

}
