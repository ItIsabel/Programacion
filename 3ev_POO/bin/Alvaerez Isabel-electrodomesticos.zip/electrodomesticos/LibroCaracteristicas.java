package electrodomesticos;

public interface LibroCaracteristicas {
	void imprimeLibroCaracteristicasElectrodomestico( );

}
