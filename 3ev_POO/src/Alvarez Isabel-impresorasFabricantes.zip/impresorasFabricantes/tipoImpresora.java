package impresorasFabricantes;

public enum tipoImpresora {
	blanco,
	negro,
	color

}
