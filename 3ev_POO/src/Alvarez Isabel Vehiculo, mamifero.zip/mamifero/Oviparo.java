package mamifero;

public interface Oviparo {
	
	public String ponerHuevos();

}
