package mamifero;

public abstract class Mamifero {
	
	

	public abstract String amamantarCrias();

}
