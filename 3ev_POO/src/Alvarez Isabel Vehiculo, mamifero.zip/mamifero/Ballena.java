
package mamifero;

public class Ballena extends Mamifero{
	

	public Ballena() {
	}

	@Override
	public String amamantarCrias() {
		return "la ballena amamanta a su hija";		
	}
	

}
