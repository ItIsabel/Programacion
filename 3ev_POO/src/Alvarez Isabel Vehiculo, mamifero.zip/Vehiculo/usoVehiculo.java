package Vehiculo;

public enum usoVehiculo {

}
