package Vehiculo;

public class Terrestre {
	int numeroLlantas;
	

}
